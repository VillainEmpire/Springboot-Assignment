package com.geekster.SpringAnnotations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAnnotationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
