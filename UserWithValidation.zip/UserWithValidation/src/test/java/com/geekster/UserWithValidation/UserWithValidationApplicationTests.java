package com.geekster.UserWithValidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserWithValidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
