package com.geekster.UserWithValidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserWithValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserWithValidationApplication.class, args);
	}

}
