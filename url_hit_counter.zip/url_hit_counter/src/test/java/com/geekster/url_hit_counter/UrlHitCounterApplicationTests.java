package com.geekster.url_hit_counter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlHitCounterApplicationTests {

	@Test
	void contextLoads() {
	}

}
