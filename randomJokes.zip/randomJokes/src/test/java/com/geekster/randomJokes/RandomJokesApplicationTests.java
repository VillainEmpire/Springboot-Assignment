package com.geekster.randomJokes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RandomJokesApplicationTests {

	@Test
	void contextLoads() {
	}

}
