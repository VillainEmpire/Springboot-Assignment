package com.geekster.UrlHitCounter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlHitCounterApplicationTests {

	@Test
	void contextLoads() {
	}

}
