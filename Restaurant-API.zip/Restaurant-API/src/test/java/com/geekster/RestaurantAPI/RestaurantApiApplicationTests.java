package com.geekster.RestaurantAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
