package com.geekster.h2Fun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2FunApplicationTests {

	@Test
	void contextLoads() {
	}

}
