package com.geekster.h2Fun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class H2FunApplication {

	public static void main(String[] args) {
		SpringApplication.run(H2FunApplication.class, args);
	}

}
